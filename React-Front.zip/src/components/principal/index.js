import React, { Component } from 'react';

export default class Principal extends Component {
    render() {
        return(
            <div className="col-sm-12">
                <h1>Bem vindo ao Sistema</h1>
            </div>
        )
    }
} 