import axios from 'axios';
const api = axios.create({ baseURL : 'http://54.221.5.196:9000' });
export default api;